# Ville CIEL et bus

La ville comprend **40 bâtiments** : les deux bâtiments d’origine et 38 nouvelles façades de logements, commerces et services (mairie, poste, pharmacie, cafés, médiathèque…). Le parc des Tilleuls, sa fontaine animée, deux ronds-points et les grands axes structurent les quartiers. Douze passants circulent sans dialogue ; les façades décoratives ne disposent pas encore d’intérieurs jouables.

Le Ritz et le bâtiment A restent à leurs anciennes positions, proches l’un de l’autre, au nord-ouest de la carte. Le parc est au centre. Les façades Sudo Hack et Louise Michel permettent de rejoindre à pied les entrées de ces bâtiments. Les arrêts existants disposent d’une signalétique de ligne et de tarif.

**Carte :** → affiche ou masque la carte par défaut ; **D** ou le joystick permet de marcher à droite. Les touches restent personnalisables. Le panneau de circulation du passage central apparaît près de celui-ci ; les autres feux sont visibles dans le décor. Le passage central conserve sa pénalité de 200 points au rouge et son retour au trottoir en cas de choc. Les voitures sont lentes et celles des nouveaux axes cèdent à proximité du joueur. La pause arrête les passants et les véhicules.

**Billet virtuel : 1 € = 10 points par trajet**, y compris le retour en ville. Aucun argent réel ni portefeuille en euros séparé. Choisissez une destination à l’arrêt du centre :

- **1 · Sudo Hack** ;
- **2 · Lycée Louise Michel**.

Le sac et l’ordinateur de l’histoire sont nécessaires avant le départ. Après validation, une courte séquence montre la montée, le paiement, l’attente assise (« En attente de destination… ») et la descente. « Passer l’animation » ou Échap termine la séquence ; le billet est déjà payé. L’option de réduction des animations permet une arrivée directe.

Le solde et l’arrivée sont sauvegardés ensemble avant l’animation. Une erreur d’écriture laisse le joueur sur place et ne débite rien. Fermer le jeu pendant la séquence reprend au point d’arrivée sans payer une deuxième fois.

Si le solde est inférieur à 10 points, le bus refuse le billet sans créer de dette. Vous pouvez rejoindre les façades des destinations à pied ; aux arrêts Sudo Hack et du lycée, « Retour à pied · gratuit » permet aussi de revenir en ville. Les missions, les récompenses déjà acquises et la dette éventuelle sont conservées.

Les façades possèdent des enseignes encadrées avec pictogrammes et lettres adaptées à leur largeur. La Poste se reconnaît à sa plaque jaune et à sa grande enveloppe. Les cinq cafés, bar et restaurants possèdent chacun deux tables avec des cafés servis, quatre chaises et une ardoise. Ces objets ont des collisions, tout en laissant le passage central des portes et les circuits piétons libres.

L’animation de bus présente une cabine en perspective : allée centrale, six sièges visibles, passagers, vitres et paysage défilant, éclairage, mains courantes, boutons d’arrêt, conducteur et tableau de bord, portes vitrées et marches. La carte de paiement rejoint le valideur, puis le joueur s’assoit avant de descendre. Le tarif, la sauvegarde et les commandes de passage de l’animation restent identiques. La cabine s’adapte également aux fenêtres de 800 × 480.
